create function aclinsert(aclitem[], aclitem) returns aclitem[]
    language internal
as
$$
aclinsert
$$;

comment on function aclinsert(_aclitem, aclitem) is 'add/update ACL item';

