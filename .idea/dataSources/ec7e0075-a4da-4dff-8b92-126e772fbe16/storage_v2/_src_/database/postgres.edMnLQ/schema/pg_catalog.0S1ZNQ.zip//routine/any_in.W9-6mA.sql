create function any_in(cstring) returns "any"
    language internal
as
$$
any_in
$$;

comment on function any_in(cstring) is 'I/O';

