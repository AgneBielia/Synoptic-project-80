create function anycompatiblenonarray_in(cstring) returns anycompatiblenonarray
    language internal
as
$$
anycompatiblenonarray_in
$$;

comment on function anycompatiblenonarray_in(cstring) is 'I/O';

