create function array_cat(anyarray, anyarray) returns anyarray
    language internal
as
$$
array_cat
$$;

comment on function array_cat(anyarray, anyarray) is 'implementation of || operator';

