create function array_to_string(anyarray, text) returns text
    language internal
as
$$
array_to_text
$$;

comment on function array_to_string(anyarray, text) is 'concatenate array elements, using delimiter, into text';

