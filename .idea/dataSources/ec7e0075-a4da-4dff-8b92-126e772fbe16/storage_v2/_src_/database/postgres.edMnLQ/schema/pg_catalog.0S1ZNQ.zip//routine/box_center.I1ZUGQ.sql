create function box_center(box) returns point
    language internal
as
$$
box_center
$$;

comment on function box_center(box) is 'implementation of @@ operator';

