create function box_contain_pt(box, point) returns boolean
    language internal
as
$$
box_contain_pt
$$;

comment on function box_contain_pt(box, point) is 'implementation of @> operator';

