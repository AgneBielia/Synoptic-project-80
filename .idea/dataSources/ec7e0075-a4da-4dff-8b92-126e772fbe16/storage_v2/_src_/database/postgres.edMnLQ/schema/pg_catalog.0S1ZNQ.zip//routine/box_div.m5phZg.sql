create function box_div(box, point) returns box
    language internal
as
$$
box_div
$$;

comment on function box_div(box, point) is 'implementation of / operator';

