create function bpcharnlike(character, text) returns boolean
    language internal
as
$$
textnlike
$$;

comment on function bpcharnlike(bpchar, text) is 'implementation of !~~ operator';

