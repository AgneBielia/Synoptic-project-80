create function bpcharout(character) returns cstring
    language internal
as
$$
bpcharout
$$;

comment on function bpcharout(bpchar) is 'I/O';

