create function btint82cmp(bigint, smallint) returns integer
    language internal
as
$$
btint82cmp
$$;

comment on function btint82cmp(int8, int2) is 'less-equal-greater';

