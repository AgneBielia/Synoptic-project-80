create function bttextnamecmp(text, name) returns integer
    language internal
as
$$
bttextnamecmp
$$;

comment on function bttextnamecmp(text, name) is 'less-equal-greater';

