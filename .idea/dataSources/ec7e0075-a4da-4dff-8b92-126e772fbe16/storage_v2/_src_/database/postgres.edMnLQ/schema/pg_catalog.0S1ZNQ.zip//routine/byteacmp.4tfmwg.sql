create function byteacmp(bytea, bytea) returns integer
    language internal
as
$$
byteacmp
$$;

comment on function byteacmp(bytea, bytea) is 'less-equal-greater';

