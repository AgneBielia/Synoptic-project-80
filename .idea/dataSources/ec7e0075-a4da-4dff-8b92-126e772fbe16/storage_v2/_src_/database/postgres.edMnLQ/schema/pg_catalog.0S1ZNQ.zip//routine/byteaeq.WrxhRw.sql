create function byteaeq(bytea, bytea) returns boolean
    language internal
as
$$
byteaeq
$$;

comment on function byteaeq(bytea, bytea) is 'implementation of = operator';

