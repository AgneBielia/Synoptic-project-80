create function charge("char", "char") returns boolean
    language internal
as
$$
charge
$$;

comment on function charge("char", "char") is 'implementation of >= operator';

