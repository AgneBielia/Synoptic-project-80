create function charsend("char") returns bytea
    language internal
as
$$
charsend
$$;

comment on function charsend("char") is 'I/O';

