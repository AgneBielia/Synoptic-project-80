create function cideq(cid, cid) returns boolean
    language internal
as
$$
cideq
$$;

comment on function cideq(cid, cid) is 'implementation of = operator';

