create function cidr_in(cstring) returns cidr
    language internal
as
$$
cidr_in
$$;

comment on function cidr_in(cstring) is 'I/O';

