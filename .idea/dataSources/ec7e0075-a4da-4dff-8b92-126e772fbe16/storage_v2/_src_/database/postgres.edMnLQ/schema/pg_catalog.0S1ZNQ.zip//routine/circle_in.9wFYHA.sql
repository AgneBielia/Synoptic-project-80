create function circle_in(cstring) returns circle
    language internal
as
$$
circle_in
$$;

comment on function circle_in(cstring) is 'I/O';

