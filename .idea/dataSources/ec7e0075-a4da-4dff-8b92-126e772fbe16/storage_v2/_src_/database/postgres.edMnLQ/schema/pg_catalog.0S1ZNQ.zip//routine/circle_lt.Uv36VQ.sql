create function circle_lt(circle, circle) returns boolean
    language internal
as
$$
circle_lt
$$;

comment on function circle_lt(circle, circle) is 'implementation of < operator';

