create function cotd(double precision) returns double precision
    language internal
as
$$
dcotd
$$;

comment on function cotd(float8) is 'cotangent, degrees';

