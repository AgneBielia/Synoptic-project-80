create function database_to_xml(nulls boolean, tableforest boolean, targetns text) returns xml
    language internal
as
$$
database_to_xml
$$;

comment on function database_to_xml(bool, bool, text) is 'map database contents to XML';

