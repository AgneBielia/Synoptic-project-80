create function date_eq_timestamp(date, timestamp without time zone) returns boolean
    language internal
as
$$
date_eq_timestamp
$$;

comment on function date_eq_timestamp(date, timestamp) is 'implementation of = operator';

