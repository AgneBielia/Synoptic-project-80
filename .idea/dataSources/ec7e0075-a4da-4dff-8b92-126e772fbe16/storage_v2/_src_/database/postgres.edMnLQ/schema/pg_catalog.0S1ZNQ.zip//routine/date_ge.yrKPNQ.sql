create function date_ge(date, date) returns boolean
    language internal
as
$$
date_ge
$$;

comment on function date_ge(date, date) is 'implementation of >= operator';

