create function date_gt(date, date) returns boolean
    language internal
as
$$
date_gt
$$;

comment on function date_gt(date, date) is 'implementation of > operator';

