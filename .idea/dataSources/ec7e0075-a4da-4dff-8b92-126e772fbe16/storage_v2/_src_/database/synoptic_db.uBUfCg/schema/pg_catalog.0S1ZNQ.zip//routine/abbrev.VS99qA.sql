create function abbrev(cidr) returns text
    immutable
    strict
    cost 1
    language internal
as
$$
cidr_abbrev
$$;

comment on function abbrev(inet) is 'abbreviated display of inet value';

