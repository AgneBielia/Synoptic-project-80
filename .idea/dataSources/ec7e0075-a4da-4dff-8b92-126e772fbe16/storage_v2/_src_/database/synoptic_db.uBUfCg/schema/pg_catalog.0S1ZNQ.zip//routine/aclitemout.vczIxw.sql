create function aclitemout(aclitem) returns cstring
    stable
    strict
    cost 1
    language internal
as
$$
aclitemout
$$;

comment on function aclitemout(aclitem) is 'I/O';

