create function acos(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dacos
$$;

comment on function acos(float8) is 'arccosine';

