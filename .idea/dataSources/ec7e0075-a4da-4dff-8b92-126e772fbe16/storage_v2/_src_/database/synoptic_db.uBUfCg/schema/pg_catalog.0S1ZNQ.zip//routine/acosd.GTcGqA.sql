create function acosd(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dacosd
$$;

comment on function acosd(float8) is 'arccosine, degrees';

