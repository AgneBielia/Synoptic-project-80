create function acosh(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dacosh
$$;

comment on function acosh(float8) is 'inverse hyperbolic cosine';

