create function amvalidate(oid) returns boolean
    strict
    cost 1
    language internal
as
$$
amvalidate
$$;

comment on function amvalidate(oid) is 'validate an operator class';

