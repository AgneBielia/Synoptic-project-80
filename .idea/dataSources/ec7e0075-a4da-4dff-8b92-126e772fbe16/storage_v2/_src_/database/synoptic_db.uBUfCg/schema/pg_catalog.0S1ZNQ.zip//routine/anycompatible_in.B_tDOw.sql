create function anycompatible_in(cstring) returns anycompatible
    immutable
    strict
    cost 1
    language internal
as
$$
anycompatible_in
$$;

comment on function anycompatible_in(cstring) is 'I/O';

