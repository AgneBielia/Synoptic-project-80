create function anycompatible_out(anycompatible) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$
anycompatible_out
$$;

comment on function anycompatible_out(anycompatible) is 'I/O';

