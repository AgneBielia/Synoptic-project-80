create function anycompatiblearray_in(cstring) returns anycompatiblearray
    immutable
    strict
    cost 1
    language internal
as
$$
anycompatiblearray_in
$$;

comment on function anycompatiblearray_in(cstring) is 'I/O';

