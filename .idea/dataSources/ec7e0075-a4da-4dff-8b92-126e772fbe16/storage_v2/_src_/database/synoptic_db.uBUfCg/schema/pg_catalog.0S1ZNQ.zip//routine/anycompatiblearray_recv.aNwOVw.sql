create function anycompatiblearray_recv(internal) returns anycompatiblearray
    stable
    strict
    cost 1
    language internal
as
$$
anycompatiblearray_recv
$$;

comment on function anycompatiblearray_recv(internal) is 'I/O';

