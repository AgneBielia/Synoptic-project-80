create function anycompatiblenonarray_in(cstring) returns anycompatiblenonarray
    immutable
    strict
    cost 1
    language internal
as
$$
anycompatiblenonarray_in
$$;

comment on function anycompatiblenonarray_in(cstring) is 'I/O';

