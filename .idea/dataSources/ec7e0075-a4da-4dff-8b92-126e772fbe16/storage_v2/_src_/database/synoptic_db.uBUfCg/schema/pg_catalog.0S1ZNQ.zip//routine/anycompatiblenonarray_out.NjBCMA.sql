create function anycompatiblenonarray_out(anycompatiblenonarray) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$
anycompatiblenonarray_out
$$;

comment on function anycompatiblenonarray_out(anycompatiblenonarray) is 'I/O';

