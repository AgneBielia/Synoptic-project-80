create function anycompatiblerange_in(cstring, oid, integer) returns anycompatiblerange
    stable
    strict
    cost 1
    language internal
as
$$
anycompatiblerange_in
$$;

comment on function anycompatiblerange_in(cstring, oid, int4) is 'I/O';

