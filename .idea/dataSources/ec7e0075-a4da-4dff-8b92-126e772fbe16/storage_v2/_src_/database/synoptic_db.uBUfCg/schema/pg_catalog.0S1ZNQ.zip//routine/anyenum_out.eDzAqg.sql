create function anyenum_out(anyenum) returns cstring
    stable
    strict
    cost 1
    language internal
as
$$
anyenum_out
$$;

comment on function anyenum_out(anyenum) is 'I/O';

