create function array_dims(anyarray) returns text
    immutable
    strict
    cost 1
    language internal
as
$$
array_dims
$$;

comment on function array_dims(anyarray) is 'array dimensions';

