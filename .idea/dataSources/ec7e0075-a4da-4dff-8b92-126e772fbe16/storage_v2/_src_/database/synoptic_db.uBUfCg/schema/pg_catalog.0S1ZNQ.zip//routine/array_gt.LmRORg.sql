create function array_gt(anyarray, anyarray) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
array_gt
$$;

comment on function array_gt(anyarray, anyarray) is 'implementation of > operator';

