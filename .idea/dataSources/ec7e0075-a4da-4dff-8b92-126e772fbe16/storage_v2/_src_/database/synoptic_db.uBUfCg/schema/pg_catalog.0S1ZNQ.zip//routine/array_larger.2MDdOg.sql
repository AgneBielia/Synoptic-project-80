create function array_larger(anyarray, anyarray) returns anyarray
    immutable
    strict
    cost 1
    language internal
as
$$
array_larger
$$;

comment on function array_larger(anyarray, anyarray) is 'larger of two';

