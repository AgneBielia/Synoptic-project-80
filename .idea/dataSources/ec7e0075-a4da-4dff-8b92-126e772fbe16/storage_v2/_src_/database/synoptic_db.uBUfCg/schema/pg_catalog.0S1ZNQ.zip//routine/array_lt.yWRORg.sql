create function array_lt(anyarray, anyarray) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
array_lt
$$;

comment on function array_lt(anyarray, anyarray) is 'implementation of < operator';

