create function array_unnest_support(internal) returns internal
    immutable
    strict
    cost 1
    language internal
as
$$
array_unnest_support
$$;

comment on function array_unnest_support(internal) is 'planner support for array_unnest';

