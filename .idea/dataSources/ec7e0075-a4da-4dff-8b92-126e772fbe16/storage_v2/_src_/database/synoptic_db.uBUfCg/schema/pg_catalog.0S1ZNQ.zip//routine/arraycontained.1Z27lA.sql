create function arraycontained(anyarray, anyarray) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
arraycontained
$$;

comment on function arraycontained(anyarray, anyarray) is 'implementation of <@ operator';

