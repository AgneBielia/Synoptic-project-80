create function arraycontjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$
arraycontjoinsel
$$;

comment on function arraycontjoinsel(internal, oid, internal, int2, internal) is 'join selectivity for array-containment operators';

