create function arrayoverlap(anyarray, anyarray) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
arrayoverlap
$$;

comment on function arrayoverlap(anyarray, anyarray) is 'implementation of && operator';

