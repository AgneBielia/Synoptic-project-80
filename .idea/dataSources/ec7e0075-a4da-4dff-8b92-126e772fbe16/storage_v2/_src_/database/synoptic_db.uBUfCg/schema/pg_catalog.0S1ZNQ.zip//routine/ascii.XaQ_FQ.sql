create function ascii(text) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$
ascii
$$;

comment on function ascii(text) is 'convert first char to int4';

