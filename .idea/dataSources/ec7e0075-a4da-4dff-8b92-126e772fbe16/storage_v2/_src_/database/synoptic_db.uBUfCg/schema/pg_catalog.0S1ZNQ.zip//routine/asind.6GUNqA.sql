create function asind(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dasind
$$;

comment on function asind(float8) is 'arcsine, degrees';

