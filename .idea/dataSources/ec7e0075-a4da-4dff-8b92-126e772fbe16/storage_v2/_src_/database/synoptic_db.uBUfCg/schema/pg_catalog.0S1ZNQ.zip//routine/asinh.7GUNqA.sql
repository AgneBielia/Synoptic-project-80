create function asinh(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dasinh
$$;

comment on function asinh(float8) is 'inverse hyperbolic sine';

