create function bit(integer, integer) returns bit
    immutable
    strict
    cost 1
    language internal
as
$$
bitfromint4
$$;

comment on function bit(int8, int4) is 'convert int8 to bitstring';

