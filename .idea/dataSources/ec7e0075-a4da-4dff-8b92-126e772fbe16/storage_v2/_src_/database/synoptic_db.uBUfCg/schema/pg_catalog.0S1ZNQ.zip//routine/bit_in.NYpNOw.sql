create function bit_in(cstring, oid, integer) returns bit
    immutable
    strict
    cost 1
    language internal
as
$$
bit_in
$$;

comment on function bit_in(cstring, oid, int4) is 'I/O';

