create function bit_out(bit) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$
bit_out
$$;

comment on function bit_out(bit) is 'I/O';

