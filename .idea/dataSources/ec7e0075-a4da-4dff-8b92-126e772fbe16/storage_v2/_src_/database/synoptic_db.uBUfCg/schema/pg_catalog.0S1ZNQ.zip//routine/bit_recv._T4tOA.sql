create function bit_recv(internal, oid, integer) returns bit
    immutable
    strict
    cost 1
    language internal
as
$$
bit_recv
$$;

comment on function bit_recv(internal, oid, int4) is 'I/O';

