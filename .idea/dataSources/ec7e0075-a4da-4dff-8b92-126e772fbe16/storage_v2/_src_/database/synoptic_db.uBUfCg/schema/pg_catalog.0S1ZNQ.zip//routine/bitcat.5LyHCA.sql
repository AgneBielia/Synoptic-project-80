create function bitcat(bit varying, bit varying) returns bit varying
    immutable
    strict
    cost 1
    language internal
as
$$
bitcat
$$;

comment on function bitcat(varbit, varbit) is 'implementation of || operator';

