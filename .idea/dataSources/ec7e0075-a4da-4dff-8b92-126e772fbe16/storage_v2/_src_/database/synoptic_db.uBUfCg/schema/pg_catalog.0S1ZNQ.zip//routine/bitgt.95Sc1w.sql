create function bitgt(bit, bit) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bitgt
$$;

comment on function bitgt(bit, bit) is 'implementation of > operator';

