create function bitle(bit, bit) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bitle
$$;

comment on function bitle(bit, bit) is 'implementation of <= operator';

