create function bitne(bit, bit) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bitne
$$;

comment on function bitne(bit, bit) is 'implementation of <> operator';

