create function bitxor(bit, bit) returns bit
    immutable
    strict
    cost 1
    language internal
as
$$
bitxor
$$;

comment on function bitxor(bit, bit) is 'implementation of # operator';

