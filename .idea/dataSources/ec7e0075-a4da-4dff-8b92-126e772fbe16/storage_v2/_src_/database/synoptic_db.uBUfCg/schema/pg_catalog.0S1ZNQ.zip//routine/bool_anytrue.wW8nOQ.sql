create function bool_anytrue(internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bool_anytrue
$$;

comment on function bool_anytrue(internal) is 'aggregate final function';

