create function booleq(boolean, boolean) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
booleq
$$;

comment on function booleq(bool, bool) is 'implementation of = operator';

