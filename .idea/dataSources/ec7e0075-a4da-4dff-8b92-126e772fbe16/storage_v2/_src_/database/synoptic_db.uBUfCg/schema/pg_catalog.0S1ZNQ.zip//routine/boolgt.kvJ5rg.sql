create function boolgt(boolean, boolean) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boolgt
$$;

comment on function boolgt(bool, bool) is 'implementation of > operator';

