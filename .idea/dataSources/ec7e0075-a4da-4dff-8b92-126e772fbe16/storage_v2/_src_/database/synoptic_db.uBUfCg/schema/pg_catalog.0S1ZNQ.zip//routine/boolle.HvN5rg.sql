create function boolle(boolean, boolean) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boolle
$$;

comment on function boolle(bool, bool) is 'implementation of <= operator';

