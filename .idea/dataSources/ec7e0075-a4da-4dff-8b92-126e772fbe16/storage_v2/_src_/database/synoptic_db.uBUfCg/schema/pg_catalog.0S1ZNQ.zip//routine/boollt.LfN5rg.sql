create function boollt(boolean, boolean) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boollt
$$;

comment on function boollt(bool, bool) is 'implementation of < operator';

