create function boolor_statefunc(boolean, boolean) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boolor_statefunc
$$;

comment on function boolor_statefunc(bool, bool) is 'aggregate transition function';

