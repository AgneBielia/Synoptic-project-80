create function boolout(boolean) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$
boolout
$$;

comment on function boolout(bool) is 'I/O';

