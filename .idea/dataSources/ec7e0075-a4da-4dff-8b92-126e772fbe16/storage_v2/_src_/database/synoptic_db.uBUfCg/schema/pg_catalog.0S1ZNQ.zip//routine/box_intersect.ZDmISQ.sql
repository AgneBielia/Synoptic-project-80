create function box_intersect(box, box) returns box
    immutable
    strict
    cost 1
    language internal
as
$$
box_intersect
$$;

comment on function box_intersect(box, box) is 'implementation of # operator';

