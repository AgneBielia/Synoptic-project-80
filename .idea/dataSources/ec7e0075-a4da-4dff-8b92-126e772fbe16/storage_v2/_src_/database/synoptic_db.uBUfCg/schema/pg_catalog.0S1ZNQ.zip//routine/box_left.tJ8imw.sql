create function box_left(box, box) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
box_left
$$;

comment on function box_left(box, box) is 'implementation of << operator';

