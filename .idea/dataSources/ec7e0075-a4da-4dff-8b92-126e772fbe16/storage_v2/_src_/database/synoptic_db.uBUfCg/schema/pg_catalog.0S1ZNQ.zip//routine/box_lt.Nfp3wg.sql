create function box_lt(box, box) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
box_lt
$$;

comment on function box_lt(box, box) is 'implementation of < operator';

