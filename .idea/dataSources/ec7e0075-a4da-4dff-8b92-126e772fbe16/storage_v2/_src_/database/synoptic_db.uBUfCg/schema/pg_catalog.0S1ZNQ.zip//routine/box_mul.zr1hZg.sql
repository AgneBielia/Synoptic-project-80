create function box_mul(box, point) returns box
    immutable
    strict
    cost 1
    language internal
as
$$
box_mul
$$;

comment on function box_mul(box, point) is 'implementation of * operator';

