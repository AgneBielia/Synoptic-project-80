create function bpchar(name) returns character
    immutable
    strict
    cost 1
    language internal
as
$$
name_bpchar
$$;

comment on function bpchar("char") is 'convert char to char(n)';

