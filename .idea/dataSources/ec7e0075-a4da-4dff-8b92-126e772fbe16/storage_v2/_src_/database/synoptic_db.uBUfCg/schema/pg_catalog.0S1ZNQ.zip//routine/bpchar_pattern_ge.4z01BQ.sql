create function bpchar_pattern_ge(character, character) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bpchar_pattern_ge
$$;

comment on function bpchar_pattern_ge(bpchar, bpchar) is 'implementation of ~>=~ operator';

