create function bpcharcmp(character, character) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$
bpcharcmp
$$;

comment on function bpcharcmp(bpchar, bpchar) is 'less-equal-greater';

