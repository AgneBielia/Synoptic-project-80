create function bpcharge(character, character) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bpcharge
$$;

comment on function bpcharge(bpchar, bpchar) is 'implementation of >= operator';

