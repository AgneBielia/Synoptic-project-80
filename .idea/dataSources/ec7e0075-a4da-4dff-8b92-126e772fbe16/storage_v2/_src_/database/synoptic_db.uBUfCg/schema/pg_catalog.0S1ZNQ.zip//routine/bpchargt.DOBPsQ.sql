create function bpchargt(character, character) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bpchargt
$$;

comment on function bpchargt(bpchar, bpchar) is 'implementation of > operator';

