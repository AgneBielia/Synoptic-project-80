create function bpchariclike(character, text) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
texticlike
$$;

comment on function bpchariclike(bpchar, text) is 'implementation of ~~* operator';

