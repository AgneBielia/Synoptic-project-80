create function bpcharicregexne(character, text) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
texticregexne
$$;

comment on function bpcharicregexne(bpchar, text) is 'implementation of !~* operator';

