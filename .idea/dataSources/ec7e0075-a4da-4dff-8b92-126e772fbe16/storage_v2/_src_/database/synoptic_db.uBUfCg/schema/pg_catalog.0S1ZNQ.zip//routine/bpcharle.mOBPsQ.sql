create function bpcharle(character, character) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bpcharle
$$;

comment on function bpcharle(bpchar, bpchar) is 'implementation of <= operator';

