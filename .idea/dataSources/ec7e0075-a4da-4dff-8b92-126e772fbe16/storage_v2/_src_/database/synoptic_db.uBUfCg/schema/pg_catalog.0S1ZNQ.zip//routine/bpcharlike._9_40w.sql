create function bpcharlike(character, text) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
textlike
$$;

comment on function bpcharlike(bpchar, text) is 'implementation of ~~ operator';

