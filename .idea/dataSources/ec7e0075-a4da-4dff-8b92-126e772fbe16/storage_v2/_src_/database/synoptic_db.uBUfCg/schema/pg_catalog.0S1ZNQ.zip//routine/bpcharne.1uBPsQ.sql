create function bpcharne(character, character) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bpcharne
$$;

comment on function bpcharne(bpchar, bpchar) is 'implementation of <> operator';

