create function json_agg(anyelement) returns json
    language internal
as
$$
aggregate_dummy
$$;

comment on function json_agg(anyelement) is 'aggregate input into json';

