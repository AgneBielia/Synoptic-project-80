create function length(text) returns integer
    stable
    strict
    cost 1
    language internal
as
$$
textlen
$$;

comment on function length(text) is 'length';

