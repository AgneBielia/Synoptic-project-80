create function length(text) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$
textlen
$$;

comment on function length(bit) is 'bitstring length';

