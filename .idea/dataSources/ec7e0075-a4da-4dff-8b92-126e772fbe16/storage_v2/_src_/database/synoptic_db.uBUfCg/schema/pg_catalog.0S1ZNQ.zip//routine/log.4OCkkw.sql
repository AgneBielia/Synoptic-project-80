create function log(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dlog10
$$;

comment on function log(numeric) is 'base 10 logarithm';

