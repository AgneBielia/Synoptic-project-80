create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(float8) is 'maximum value of all float8 input values';

