create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(money) is 'maximum value of all money input values';

