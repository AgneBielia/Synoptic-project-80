create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(interval) is 'maximum value of all interval input values';

