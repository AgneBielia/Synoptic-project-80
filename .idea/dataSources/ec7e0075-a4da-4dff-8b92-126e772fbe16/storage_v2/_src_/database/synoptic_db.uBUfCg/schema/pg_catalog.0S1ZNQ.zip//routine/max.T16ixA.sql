create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(timestamptz) is 'maximum value of all timestamp with time zone input values';

