create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(int8) is 'maximum value of all bigint input values';

