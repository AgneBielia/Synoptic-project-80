create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(timestamp) is 'maximum value of all timestamp input values';

