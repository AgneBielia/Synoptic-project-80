create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(int2) is 'minimum value of all smallint input values';

