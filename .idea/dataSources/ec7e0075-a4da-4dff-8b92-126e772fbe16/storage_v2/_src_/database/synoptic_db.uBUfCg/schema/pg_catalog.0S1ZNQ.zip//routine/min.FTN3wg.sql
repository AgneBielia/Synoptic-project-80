create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(bpchar) is 'minimum value of all bpchar input values';

