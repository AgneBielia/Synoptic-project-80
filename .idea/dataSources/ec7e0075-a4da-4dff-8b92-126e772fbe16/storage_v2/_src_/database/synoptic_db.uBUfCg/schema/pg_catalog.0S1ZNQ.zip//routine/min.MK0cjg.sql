create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(pg_lsn) is 'minimum value of all pg_lsn input values';

