create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(time) is 'minimum value of all time input values';

