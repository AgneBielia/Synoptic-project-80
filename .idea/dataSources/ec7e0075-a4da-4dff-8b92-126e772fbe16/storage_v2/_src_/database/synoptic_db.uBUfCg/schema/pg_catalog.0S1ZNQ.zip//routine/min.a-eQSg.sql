create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(oid) is 'minimum value of all oid input values';

