create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(timetz) is 'minimum value of all time with time zone input values';

