create function mode(ORDER BY anyelement) returns anyelement
    language internal
as
$$
aggregate_dummy
$$;

comment on function mode(anyelement) is 'most common value';

