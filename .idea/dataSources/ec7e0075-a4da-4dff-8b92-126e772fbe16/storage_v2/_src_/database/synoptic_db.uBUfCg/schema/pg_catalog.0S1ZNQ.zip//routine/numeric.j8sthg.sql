create function numeric(money) returns numeric
    stable
    strict
    cost 1
    language internal
as
$$
cash_numeric
$$;

comment on function numeric(int2) is 'convert int2 to numeric';

