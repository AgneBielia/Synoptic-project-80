create function "overlaps"(time with time zone, time with time zone, time with time zone, time with time zone) returns boolean
    stable
    cost 1
    language internal
as
$$
overlaps_timetz
$$;

comment on function "overlaps"(time, interval, time, interval) is 'intervals overlap?';

