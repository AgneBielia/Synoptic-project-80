create function percent_rank("$1" any) returns double precision
    language internal
as
$$
window_percent_rank
$$;

comment on function percent_rank(any) is 'fractional rank of hypothetical row';

