create function percentile_cont(double precision ORDER BY double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function percentile_cont(float8, float8) is 'continuous distribution percentile';

