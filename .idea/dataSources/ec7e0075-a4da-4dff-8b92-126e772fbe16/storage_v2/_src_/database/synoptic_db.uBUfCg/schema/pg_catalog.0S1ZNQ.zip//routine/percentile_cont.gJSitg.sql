create function percentile_cont(double precision ORDER BY double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function percentile_cont(_float8, float8) is 'multiple continuous percentiles';

