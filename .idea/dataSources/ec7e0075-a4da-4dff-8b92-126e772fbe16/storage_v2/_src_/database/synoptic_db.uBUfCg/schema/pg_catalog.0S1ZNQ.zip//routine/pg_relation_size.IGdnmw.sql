create function pg_relation_size(regclass) returns bigint
    strict
    cost 1
    language sql
as
$$
select pg_catalog.pg_relation_size($1, 'main')
$$;

comment on function pg_relation_size(regclass, text) is 'disk space usage for the specified fork of a table or index';

