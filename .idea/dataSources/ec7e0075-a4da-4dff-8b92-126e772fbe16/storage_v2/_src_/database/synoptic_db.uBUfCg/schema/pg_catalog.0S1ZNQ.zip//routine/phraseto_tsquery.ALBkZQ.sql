create function phraseto_tsquery(text) returns tsquery
    immutable
    strict
    language internal
as
$$
phraseto_tsquery
$$;

comment on function phraseto_tsquery(regconfig, text) is 'transform to tsquery';

