create function phraseto_tsquery(text) returns tsquery
    stable
    strict
    language internal
as
$$
phraseto_tsquery
$$;

comment on function phraseto_tsquery(text) is 'transform to tsquery';

