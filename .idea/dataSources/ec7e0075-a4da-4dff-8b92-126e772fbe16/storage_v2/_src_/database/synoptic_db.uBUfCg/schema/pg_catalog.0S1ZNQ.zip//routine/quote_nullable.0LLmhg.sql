create function quote_nullable(text) returns text
    stable
    cost 1
    language internal
as
$$
quote_nullable
$$;

comment on function quote_nullable(text) is 'quote a possibly-null literal for usage in a querystring';

