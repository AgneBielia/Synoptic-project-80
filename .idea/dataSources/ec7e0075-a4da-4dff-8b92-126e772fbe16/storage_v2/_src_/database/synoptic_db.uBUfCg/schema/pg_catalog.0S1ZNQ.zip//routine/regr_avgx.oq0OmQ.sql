create function regr_avgx(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_avgx(float8, float8) is 'average of the independent variable (sum(X)/N)';

