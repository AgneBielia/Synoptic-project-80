create function regr_avgy(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_avgy(float8, float8) is 'average of the dependent variable (sum(Y)/N)';

