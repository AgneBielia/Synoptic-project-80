create function regr_count(double precision, double precision) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_count(float8, float8) is 'number of input rows in which both expressions are not null';

