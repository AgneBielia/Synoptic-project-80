create function regr_intercept(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_intercept(float8, float8) is 'y-intercept of the least-squares-fit linear equation determined by the (X, Y) pairs';

