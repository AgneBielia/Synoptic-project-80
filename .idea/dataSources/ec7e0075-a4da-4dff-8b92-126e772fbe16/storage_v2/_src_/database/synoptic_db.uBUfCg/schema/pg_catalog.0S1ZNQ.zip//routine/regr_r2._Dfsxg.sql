create function regr_r2(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_r2(float8, float8) is 'square of the correlation coefficient';

