create function regr_slope(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_slope(float8, float8) is 'slope of the least-squares-fit linear equation determined by the (X, Y) pairs';

