create function regr_sxx(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_sxx(float8, float8) is 'sum of squares of the independent variable (sum(X^2) - sum(X)^2/N)';

