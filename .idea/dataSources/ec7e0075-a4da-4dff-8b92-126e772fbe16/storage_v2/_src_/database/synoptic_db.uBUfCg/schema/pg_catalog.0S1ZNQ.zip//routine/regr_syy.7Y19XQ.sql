create function regr_syy(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_syy(float8, float8) is 'sum of squares of the dependent variable (sum(Y^2) - sum(Y)^2/N)';

