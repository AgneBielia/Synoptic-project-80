create function stddev(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function stddev(int4) is 'historical alias for stddev_samp';

