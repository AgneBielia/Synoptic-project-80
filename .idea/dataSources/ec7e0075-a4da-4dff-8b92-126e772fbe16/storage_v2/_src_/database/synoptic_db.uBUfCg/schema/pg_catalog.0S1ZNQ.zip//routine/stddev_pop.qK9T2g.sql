create function stddev_pop(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function stddev_pop(int4) is 'population standard deviation of integer input values';

