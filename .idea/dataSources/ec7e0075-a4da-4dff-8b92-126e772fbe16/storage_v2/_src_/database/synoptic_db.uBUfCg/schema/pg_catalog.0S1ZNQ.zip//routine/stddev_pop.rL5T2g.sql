create function stddev_pop(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function stddev_pop(int8) is 'population standard deviation of bigint input values';

