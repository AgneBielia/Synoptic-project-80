create function stddev_samp(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function stddev_samp(float8) is 'sample standard deviation of float8 input values';

