create function stddev_samp(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function stddev_samp(numeric) is 'sample standard deviation of numeric input values';

