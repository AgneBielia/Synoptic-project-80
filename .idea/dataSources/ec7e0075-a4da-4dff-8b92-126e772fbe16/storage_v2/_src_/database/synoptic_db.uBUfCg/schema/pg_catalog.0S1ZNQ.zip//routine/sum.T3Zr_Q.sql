create function sum(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function sum(int4) is 'sum as bigint across all integer input values';

