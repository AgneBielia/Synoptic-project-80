create function sum(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function sum(int8) is 'sum as numeric across all bigint input values';

