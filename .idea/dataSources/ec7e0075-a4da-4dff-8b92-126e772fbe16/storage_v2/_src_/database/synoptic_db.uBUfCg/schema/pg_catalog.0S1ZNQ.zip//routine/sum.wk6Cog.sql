create function sum(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function sum(float4) is 'sum as float4 across all float4 input values';

