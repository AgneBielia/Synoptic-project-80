create function sum(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function sum(float8) is 'sum as float8 across all float8 input values';

