create function timestamptz(date) returns timestamp with time zone
    stable
    strict
    cost 1
    language internal
as
$$
date_timestamptz
$$;

comment on function timestamptz(date, time) is 'convert date and time to timestamp with time zone';

