create function trunc(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dtrunc
$$;

comment on function trunc(numeric) is 'value truncated to ''scale'' of zero';

