create function ts_rewrite(tsquery, text) returns tsquery
    strict
    language internal
as
$$
tsquery_rewrite_query
$$;

comment on function ts_rewrite(tsquery, tsquery, tsquery) is 'rewrite tsquery';

