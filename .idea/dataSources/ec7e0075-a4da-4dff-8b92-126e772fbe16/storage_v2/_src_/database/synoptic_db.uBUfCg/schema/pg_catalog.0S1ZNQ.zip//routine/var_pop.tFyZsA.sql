create function var_pop(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function var_pop(float8) is 'population variance of float8 input values (square of the population standard deviation)';

