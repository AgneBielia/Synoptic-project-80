create function variance(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function variance(numeric) is 'historical alias for var_samp';

