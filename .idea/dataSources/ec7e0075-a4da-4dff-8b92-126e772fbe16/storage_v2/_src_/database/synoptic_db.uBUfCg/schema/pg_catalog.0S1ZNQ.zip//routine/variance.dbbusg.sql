create function variance(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function variance(int4) is 'historical alias for var_samp';

