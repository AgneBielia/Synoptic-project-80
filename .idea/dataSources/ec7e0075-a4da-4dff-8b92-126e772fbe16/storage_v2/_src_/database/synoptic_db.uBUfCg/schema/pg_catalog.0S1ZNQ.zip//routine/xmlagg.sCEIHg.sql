create function xmlagg(xml) returns xml
    language internal
as
$$
aggregate_dummy
$$;

comment on function xmlagg(xml) is 'concatenate XML values';

